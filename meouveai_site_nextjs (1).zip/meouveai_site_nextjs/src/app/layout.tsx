import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header"; // Import Header
import Footer from "@/components/Footer"; // Import Footer

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Me Ouve AI - Escuta Inteligente para Empresas Responsáveis",
  description: "Soluções com IA para liberar o potencial emocional e estratégico das organizações.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className={`${inter.className} bg-gray-50 text-gray-900 flex flex-col min-h-screen`}>
        <Header /> {/* Add Header component */}
        <main className="flex-grow flex flex-col items-center justify-start w-full">
          {children}
        </main>
        <Footer /> {/* Add Footer component */}
      </body>
    </html>
  );
}
