import React from 'react';

// Import components for each section (optional, can be inline)
// import HeroSection from '@/components/HeroSection';
// import ProblemsSection from '@/components/ProblemsSection';
// import SolutionSection from '@/components/SolutionSection';
// import BenefitsSection from '@/components/BenefitsSection';
// import HowItWorksSection from '@/components/HowItWorksSection';
// import CumeSection from '@/components/CumeSection';
// import FinalCallSection from '@/components/FinalCallSection';
// import ContactSection from '@/components/ContactSection';

export default function Home() {
  return (
    <div className="w-full max-w-6xl mx-auto flex flex-col items-center space-y-16 md:space-y-24 px-4">

      {/* Hero Section */}
      <section id="hero" className="w-full text-center pt-16 pb-8 md:pt-24 md:pb-12">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-blue-800 mb-4">
          Me Ouve AI: Escuta Inteligente
        </h1>
        <p className="text-xl md:text-2xl text-gray-700 mb-8">
          Soluções com IA para liberar o potencial emocional e estratégico das organizações.
        </p>
        <a
          href="#contato" // Link to contact section
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg text-lg transition duration-300 ease-in-out inline-block"
        >
          Solicitar Demonstração
        </a>
      </section>

      {/* Problems Section */}
      <section id="problemas" className="w-full py-12 bg-gray-100 rounded-lg shadow-sm">
        <div className="container mx-auto px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-10">Os Problemas Atuais nas Empresas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Falta de Escuta Real</h3>
              <p className="text-gray-600">Metas abundantes, mas ausência de diálogo emocional autêntico.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Colaboradores Sobrecarregados</h3>
              <p className="text-gray-600">Sem espaços seguros para desabafar e expressar emoções.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Desafio para Líderes</h3>
              <p className="text-gray-600">Sentimento de solidão e pressão, sem apoio emocional.</p>
            </div>
             <div className="bg-white p-6 rounded-lg shadow-md text-center md:col-span-2 lg:col-span-1 lg:col-start-2">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">RH Operando no Escuro</h3>
              <p className="text-gray-600">Falta de dados emocionais estratégicos para decisões assertivas.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section id="solucao" className="w-full py-12">
        <div className="container mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">A Solução: Plataforma Me Ouve AI</h2>
          <p className="text-lg text-gray-600 mb-10 max-w-3xl mx-auto">Nossa plataforma utiliza Inteligência Artificial para oferecer uma escuta emocional humanizada, transformando pessoas, cultura e tomadas de decisão na sua empresa.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="border border-blue-200 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Agente para Colaboradores</h3>
              <p className="text-gray-600">Um espaço seguro e confidencial para desabafo, onde a IA entende, respeita e responde com empatia.</p>
            </div>
            <div className="border border-blue-200 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Agente para Líderes</h3>
              <p className="text-gray-600">Ferramenta de reflexão sobre decisões, propósito e gestão de equipes, promovendo uma liderança mais consciente.</p>
            </div>
            <div className="border border-blue-200 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Agente para RH</h3>
              <p className="text-gray-600">Relatórios anonimizados com insights valiosos sobre o clima organizacional para ações inteligentes e estratégicas.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="w-full py-12 bg-blue-50 rounded-lg shadow-sm">
        <div className="container mx-auto px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-10">Benefícios Estratégicos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Bem-Estar e Engajamento</h3>
              <p className="text-gray-600">Melhora significativa no bem-estar dos colaboradores, reduzindo o estresse e aumentando o engajamento.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Apoio à Liderança</h3>
              <p className="text-gray-600">Líderes mais preparados para tomar decisões complexas com clareza, coragem e visão humana.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Insights para o RH</h3>
              <p className="text-gray-600">Relatórios anonimizados fornecem dados estratégicos para ações de RH mais eficazes e direcionadas.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-blue-700 mb-3">Conformidade e Cultura</h3>
              <p className="text-gray-600">Atende à NR-1 sobre saúde mental e fortalece uma cultura organizacional focada em ESG e liderança consciente.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section id="como-funciona" className="w-full py-12">
        <div className="container mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-10">Como Funciona o Me Ouve AI</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="flex flex-col items-center">
              {/* Icon Placeholder */}
              <div className="bg-blue-100 p-4 rounded-full mb-4"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg></div>
              <h3 className="text-lg font-semibold text-gray-700 mb-2">Acesso Seguro</h3>
              <p className="text-gray-600 text-sm">Login individual e seguro para colaboradores, líderes e RH.</p>
            </div>
            <div className="flex flex-col items-center">
              {/* Icon Placeholder */}
              <div className="bg-blue-100 p-4 rounded-full mb-4"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg></div>
              <h3 className="text-lg font-semibold text-gray-700 mb-2">Conversa Aberta e IA Humanizada</h3>
              <p className="text-gray-600 text-sm">Ambiente seguro para diálogo franco, com IA que organiza e responde com empatia estratégica.</p>
            </div>
            <div className="flex flex-col items-center">
              {/* Icon Placeholder */}
              <div className="bg-blue-100 p-4 rounded-full mb-4"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.753 20.571M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4" /></svg></div>
              <h3 className="text-lg font-semibold text-gray-700 mb-2">Anonimidade Garantida</h3>
              <p className="text-gray-600 text-sm">100% de anonimidade, sem armazenamento de dados pessoais identificáveis.</p>
            </div>
            <div className="flex flex-col items-center">
              {/* Icon Placeholder */}
              <div className="bg-blue-100 p-4 rounded-full mb-4"><svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg></div>
              <h3 className="text-lg font-semibold text-gray-700 mb-2">Relatórios para Liderança</h3>
              <p className="text-gray-600 text-sm">Dados coletivos e anonimizados para decisões estratégicas e inteligentes.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CUME Agent Section */}
      <section id="cume" className="w-full py-12 bg-gray-100 rounded-lg shadow-sm">
        <div className="container mx-auto px-6 lg:px-8 flex flex-col md:flex-row items-center gap-8">
          <div className="md:w-1/2 text-center md:text-left">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Nosso Agente CUME: Espaço Seguro para Líderes</h2>
            <p className="text-lg text-gray-600 mb-6">Líderes C-Level enfrentam decisões complexas e pressões intensas, muitas vezes isolados. O CUME oferece um ambiente profundo, seguro e inteligente para reflexão honesta.</p>
            <p className="text-gray-600">Permite clareza, coragem e visão para liderar com humanidade, transformando desafios em oportunidades estratégicas.</p>
          </div>
          <div className="md:w-1/2">
            {/* Placeholder for an image or illustration */}
            <div className="bg-blue-200 h-64 rounded-lg flex items-center justify-center text-gray-500">
              [Imagem/Ilustração Representando Liderança/Reflexão]
            </div>
          </div>
        </div>
      </section>

      {/* Final Call Section */}
      <section id="convite" className="w-full py-16 text-center bg-gradient-to-r from-blue-700 to-blue-900 text-white rounded-lg shadow-lg">
        <div className="container mx-auto px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Faça Parte da Revolução Humana</h2>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">Empresas extraordinárias nascem da escuta ativa, consciência e humanidade. Me Ouve AI é mais que tecnologia, é um convite para transformar as relações no trabalho.</p>
          <p className="text-2xl md:text-3xl font-semibold mb-10">Você está pronto para liderar o futuro com empatia e inteligência?</p>
          <a
            href="#contato" // Link to contact section
            className="bg-white hover:bg-gray-100 text-blue-800 font-bold py-3 px-8 rounded-lg text-lg transition duration-300 ease-in-out inline-block shadow-md"
          >
            Solicitar Demonstração Agora
          </a>
        </div>
      </section>

      {/* Contact Section Placeholder */}
      <section id="contato" className="w-full py-12">
        <div className="container mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">Entre em Contato</h2>
          <p className="text-lg text-gray-600 mb-8">Solicite uma demonstração e descubra como o Me Ouve AI pode transformar sua empresa.</p>
          {/* Placeholder for a contact form or contact information */}
          <div className="bg-white p-8 rounded-lg shadow-md max-w-lg mx-auto">
            <p className="text-gray-700">[Formulário de Contato ou Informações de Contato Aqui]</p>
            <p className="mt-4 text-sm text-gray-500">Ex: Preencha o formulário abaixo ou envie um email para contato@meouve.ai</p>
          </div>
        </div>
      </section>

    </div>
  );
}

