import Image from 'next/image';
import Link from 'next/link';

const Footer = () => {
  return (
    <footer className="w-full bg-gray-800 text-gray-300 py-8 mt-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between">
        <div className="flex items-center mb-4 md:mb-0">
          <Image
            src="/logo-meouveai.png" // Use the static PNG logo
            alt="Me Ouve AI Logo Estático"
            width={120} // Adjust width as needed
            height={32} // Adjust height as needed
          />
          <span className="ml-4 text-sm">&copy; {new Date().getFullYear()} Me Ouve AI. Todos os direitos reservados.</span>
        </div>
        {/* Optional: Add footer links here */}
        {/* <div className="flex space-x-6">
          <Link href="/termos" className="hover:text-white text-sm">Termos de Uso</Link>
          <Link href="/privacidade" className="hover:text-white text-sm">Política de Privacidade</Link>
        </div> */}
      </div>
    </footer>
  );
};

export default Footer;
