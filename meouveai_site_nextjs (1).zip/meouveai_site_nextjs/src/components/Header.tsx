import Image from 'next/image';
import Link from 'next/link';

const Header = () => {
  return (
    <header className="w-full bg-white shadow-md sticky top-0 z-50">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
        <div className="flex-shrink-0">
          <Link href="/" className="flex items-center">
            <Image
              src="/logo-meouveai_gif.gif" // Use the animated GIF logo
              alt="Me Ouve AI Logo"
              width={150} // Adjust width as needed, ensure responsiveness
              height={40} // Adjust height as needed
              unoptimized // Necessary for GIF
              priority
            />
          </Link>
        </div>
        {/* Navigation links can be added here if needed */}
        {/* Example:
        <div className="hidden md:flex space-x-8">
          <Link href="#solucao" className="text-gray-600 hover:text-blue-600">Solução</Link>
          <Link href="#beneficios" className="text-gray-600 hover:text-blue-600">Benefícios</Link>
          <Link href="#como-funciona" className="text-gray-600 hover:text-blue-600">Como Funciona</Link>
        </div>
        */}
        <div className="flex items-center">
          <a
            href="#contato" // Link to a contact section or form
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out"
          >
            Solicitar Demonstração
          </a>
        </div>
      </nav>
    </header>
  );
};

export default Header;
